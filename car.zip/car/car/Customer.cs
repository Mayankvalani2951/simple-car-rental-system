﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace car
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }
      
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");
        private void populate()
        {
            con.Open();
            string query = "select * from Customertbl";

            SqlDataAdapter da = new SqlDataAdapter(query, con);
          
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            customerDGV.DataSource = ds.Tables[0];
            con.Close();
          


        }
     
        private void Customer_Load(object sender, EventArgs e)
        {
            string sql = "select * from Customertbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            customerDGV.DataSource = dt;
            populate();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

            if (idtb.Text == "" || custnm.Text == "" || custadd.Text == "" || custphone.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con1.Open();
                    string query = "insert into Customertbl values(" + idtb.Text + ",'" + custnm.Text + "','" + custadd.Text + "','" + custphone.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con1);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Add");
                    con1.Close();
                    populate();
                   
                    idtb.Text =custnm.Text = custadd.Text = custphone.Text = String.Empty;
                    idtb.Focus();
                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
            }

        private void btnedit_Click(object sender, EventArgs e)
        {
            if (idtb.Text == "" || custnm.Text == "" || custadd.Text == "" || custphone.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Customertbl set CustName='"+custnm.Text+"',CustAdd='"+custadd.Text+"',Phone='"+custphone.Text+"' where CustId="+idtb.Text+";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated");
                    con.Close();
                    populate();
                  
                    idtb.Text= custnm.Text = custadd.Text = custphone.Text = String.Empty;
                    idtb.Focus();
                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

            private void btndelete_Click(object sender, EventArgs e)
        {

            if (idtb.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from Customertbl where CustId=" + idtb.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Delete");
                    con.Close();
                    populate();
                   
                    idtb.Text = custnm.Text = custadd.Text = custphone.Text = String.Empty;
                    idtb.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
            
        }

        private void custid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

        private void custphone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
         
        }

      
        
   

        private void customerDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
             int a=e.RowIndex;
            if (a > -1)
            {

                    idtb.Text = customerDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                    custnm.Text = customerDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                    custadd.Text = customerDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                    custphone.Text = customerDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
          //  Panel p = sender as Panel;
          //  ControlPaint.DrawBorder(e.Graphics, p.DisplayRectangle, Color.Yellow, ButtonBorderStyle.Inset);

        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.pictureBox2.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        private void Customer_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Rectangle rect = new Rectangle(idtb.Location.X, idtb.Location.Y, idtb.ClientSize.Width, idtb.ClientSize.Height);

            rect.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect1 = new Rectangle(custnm.Location.X, custnm.Location.Y, custnm.ClientSize.Width, custnm.ClientSize.Height);

            rect1.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect1, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect2 = new Rectangle(custadd.Location.X, custadd.Location.Y, custadd.ClientSize.Width, custadd.ClientSize.Height);

            rect2.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect2, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect3 = new Rectangle(custphone.Location.X, custphone.Location.Y, custphone.ClientSize.Width, custphone.ClientSize.Height);

            rect3.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect3, Color.Aqua, ButtonBorderStyle.Solid);

        }
    }
}
