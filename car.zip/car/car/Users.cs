﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Users : Form
    {
        string id = string.Empty;
        int tr = 0;
        int rp = 0;
        int menuitem = 0;
        public Users()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");
        private void populate()
        {
        
            string query = "select * from Usertbl";

           SqlDataAdapter da = new SqlDataAdapter(query,con);
         //  SqlCommandBuilder builder = new SqlCommandBuilder(da);
            DataTable dt = new DataTable();
            da.Fill(dt);
           // usersDGV.DataSource = ds.Tables[0];
           
            tr = dt.Rows.Count - 1;
            if (menuitem == 0)
            {
                if (dt.Rows.Count == 0)
                {
                    id = "1";
                    uid.Text = id;
                }
                else
                {
                    tr = dt.Rows.Count - 1;
                    string tempid = dt.Rows[tr][0].ToString();
                    string getid = tempid.Substring(0);
                    int newtempid = Convert.ToInt32(getid) + 1;
                    uid.Text = "0" + newtempid.ToString("0");
                    id = uid.Text;
                }
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

            if (uid.Text == "" ||uname.Text == "" || upass.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Usertbl values('" + uid.Text + "','" + uname.Text + "','" + upass.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Add");
                    populate();
                    getdata();
                    con.Close();
                   
                     uname.Text = upass.Text =string.Empty;
                    

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
               
            




        }
       
        private void User_Load(object sender, EventArgs e)
        {
            string sql = "select * from Usertbl";
            SqlDataAdapter da = new SqlDataAdapter(sql,con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            usersDGV.DataSource = dt;
           



            
            populate();

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (uid.Text == "" )
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from Usertbl where id="+uid.Text+";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Delete");
                    con.Close();
                    populate();
                    getdata();
                    uname.Text = upass.Text = string.Empty;
                    uname.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }


        }




        private void btnback_Click(object sender, EventArgs e)
        {
           
         
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {

            if (uid.Text == "" || uname.Text == "" || upass.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Usertbl set uname='"+uname.Text+"',upass='"+upass.Text+"' where id="+uid.Text+";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Update");
                    con.Close();
                    populate();
                    getdata();
                   uname.Text = upass.Text = string.Empty;
                    uname.Focus();
                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }


        }

       

        private void label4_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void uid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

       

       

      

        private void uname_TextChanged(object sender, EventArgs e)
        {
           
            this.uname.BackColor = Color.Black;
            
        }

        private void Users_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Rectangle rect = new Rectangle(uid.Location.X, uid.Location.Y, uid.ClientSize.Width, uid.ClientSize.Height);

            rect.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect1 = new Rectangle(uname.Location.X, uname.Location.Y, uname.ClientSize.Width, uname.ClientSize.Height);

            rect1.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect1, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect2 = new Rectangle(upass.Location.X, upass.Location.Y, upass.ClientSize.Width, upass.ClientSize.Height);

            rect2.Inflate(1, 1); // border thickness
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect2, Color.Aqua, ButtonBorderStyle.Solid);

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            ControlPaint.DrawBorder(e.Graphics, p.DisplayRectangle, Color.Yellow, ButtonBorderStyle.Inset);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.pictureBox2.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);

        }

        private void usersDGV_Paint(object sender, PaintEventArgs e)
        {
            Rectangle rect=usersDGV.ClientRectangle;
            rect.Width--;
            rect.Height--;
            e.Graphics.DrawRectangle(new Pen(Color.Red,1), rect); 

        }

        private void usersDGV_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if(e.Value!=null && e.Value.ToString()=="somevalue")
            {
                e.CellStyle.BackColor = Color.LightBlue;
            }
        }

        private void usersDGV_GridColorChanged(object sender, EventArgs e)
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            style.BackColor = Color.White;

            
        }

        private void usersDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int a = e.RowIndex;
            if (a > -1)
            {
                uid.Text = usersDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                uname.Text = usersDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                upass.Text = usersDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            }
        }

     

        private void getdata()
        {
            string a = "select * from Usertbl";
            SqlDataAdapter da = new SqlDataAdapter(a, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            usersDGV.DataSource = dt;
        }

    }
}
