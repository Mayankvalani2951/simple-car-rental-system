﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Return : Form
    {
       
        public Return()
        {
            InitializeComponent();
        }
  
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");
      
        private void populate()
        {
            con.Open();
            string query = "select * from Rentaltbl ";
            SqlDataAdapter da = new SqlDataAdapter(query,con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            rentDGV.DataSource = ds.Tables[0];
            con.Close();

        }
        private void populateRet()
        {
            string query = "select * from Returntbl ";
            SqlDataAdapter da = new SqlDataAdapter(query,con);
          
           SqlCommandBuilder builder = new SqlCommandBuilder(da);
           var ds = new DataSet();
           da.Fill(ds);
           returnDGV.DataSource = ds.Tables[0];
          
         }
     
        private void Deleteonreturn(string carid)
          {
           
            con.Open();
             string query = "delete from Rentaltbl where carReg= '" + carid+"'";
             SqlCommand cmd = new SqlCommand(query,con);
             cmd.ExecuteNonQuery();
             
             con.Close();
             populate();
           


          }
  





        private void Return_Load(object sender, EventArgs e)
        {
            string sql = "select * from Rentaltbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rentDGV.DataSource = dt;

            string sql1 = "select * from Returntbl";
            SqlDataAdapter da1 = new SqlDataAdapter(sql1, con);
            DataTable dt1 = new DataTable();
            da.Fill(dt);
            returnDGV.DataSource = dt;


            populate();
            populateRet();
          



        }


         private void btnadd_Click(object sender, EventArgs e)
              {
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");


            if (IdTb.Text == "" || returncarid.Text == "" || returnname.Text == "" || rdate.Text == "" || rdelay.Text == ""|| rfine.Text == "")
                  {
                      MessageBox.Show("missing information");
                  }
                  else
                  {
                      try
                      {
                        string carid = returncarid.Text;
                        Deleteonreturn(carid);

                        con1.Open();
                          string query = "insert into Returntbl values(" + IdTb.Text + ",'" + returncarid.Text + "','" + returnname.Text + "','" + rdate.Text + "','" + rdelay.Text + "'," + rfine.Text + ")";
                          SqlCommand cmd = new SqlCommand(query, con1);
                          cmd.ExecuteNonQuery();
                          MessageBox.Show("success return");
                          populateRet();
                  
                         IdTb.Text = returncarid.Text =returnname.Text = rdelay.Text =rfine.Text = string.Empty;
                         IdTb.Focus();
                          con1.Close();

                        }
                      catch (Exception myex)
                      {
                          MessageBox.Show(myex.Message);
                      }
                  }

              }
    
        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
            
        }

       
        

        private void rid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

      

        private void rfine_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }




        private void rentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int a = e.RowIndex;
            if (a > -1)
            {
               IdTb.Text = rentDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                returncarid.Text = rentDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                returnname.Text = rentDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                rdate.Text = rentDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                DateTime d1 = rdate.Value.Date;
                DateTime d2 = DateTime.Now;
                TimeSpan t = d1 - d2;
                int NrofDays = Convert.ToInt32(t.TotalDays);
                if (NrofDays <= 0)
                {
                    rdelay.Text = "No Delay";
                    rfine.Text = "0";
                }
                else
                {
                    rdelay.Text = "" + NrofDays;
                    rfine.Text = "" + (NrofDays * 250);


                }
            }
        }
     


      

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, Color.Yellow, ButtonBorderStyle.Solid);

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

       

     

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.pictureBox2.ClientRectangle, Color.Yellow, ButtonBorderStyle.Solid);

        }

     

        private void Return_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Rectangle rect = new Rectangle(IdTb.Location.X, IdTb.Location.Y, IdTb.ClientSize.Width, IdTb.ClientSize.Height);

            rect.Inflate(1, 1); 
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect1 = new Rectangle(returncarid.Location.X, returncarid.Location.Y, returncarid.ClientSize.Width, returncarid.ClientSize.Height);

            rect1.Inflate(1, 1);
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect1, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect2 = new Rectangle(returnname.Location.X, returnname.Location.Y, returnname.ClientSize.Width, returnname.ClientSize.Height);

            rect2.Inflate(1, 1); 
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect2, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect3 = new Rectangle(rdate.Location.X, rdate.Location.Y, rdate.ClientSize.Width, rdate.ClientSize.Height);

            rect3.Inflate(1, 1); 
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect3, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect4 = new Rectangle(rdelay.Location.X, rdelay.Location.Y, rdelay.ClientSize.Width, rdelay.ClientSize.Height);

            rect4.Inflate(1, 1); 
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect4, Color.Aqua, ButtonBorderStyle.Solid);
            System.Drawing.Rectangle rect5 = new Rectangle(rfine.Location.X, rfine.Location.Y, rfine.ClientSize.Width, rfine.ClientSize.Height);

            rect5.Inflate(1, 1); 
            System.Windows.Forms.ControlPaint.DrawBorder(e.Graphics, rect5, Color.Aqua, ButtonBorderStyle.Solid);

        }

        private void returnDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int a = e.RowIndex;
            if (a > -1)
            {
                IdTb.Text = returnDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
                returncarid.Text = returnDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
                returnname.Text = returnDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                rdate.Text = returnDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                rdelay.Text = returnDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                rfine.Text = returnDGV.Rows[e.RowIndex].Cells[5].Value.ToString();
            }
        }

        private void btndelete_Click_1(object sender, EventArgs e)
        {
            if (IdTb.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from Returntbl where ReturnId=" + IdTb.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record delete");
                    con.Close();
                    populateRet();
                  

                    IdTb.Text = returncarid.Text = returnname.Text = rdate.Text = rdelay.Text = rfine.Text = string.Empty;
                    IdTb.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
        }

       
    }
}
