﻿namespace car
{
    partial class Car
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Car));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnback = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnedit = new System.Windows.Forms.Button();
            this.brand = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Button();
            this.model = new System.Windows.Forms.TextBox();
            this.rno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.TextBox();
            this.cartblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cartblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.cartblBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.cartblBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.carDGV = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.ComboBox();
            this.available = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Location = new System.Drawing.Point(-10, -5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(825, 95);
            this.panel1.TabIndex = 18;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(220, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(364, 54);
            this.label7.TabIndex = 41;
            this.label7.Text = "Car Register";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(41, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 95);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 40;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox2_Paint);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Black;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.ForeColor = System.Drawing.Color.Cyan;
            this.btnback.Location = new System.Drawing.Point(117, 368);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(82, 35);
            this.btnback.TabIndex = 8;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click_1);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.Black;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.ForeColor = System.Drawing.Color.Red;
            this.btndelete.Location = new System.Drawing.Point(229, 316);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(82, 35);
            this.btndelete.TabIndex = 7;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click_1);
            // 
            // btnedit
            // 
            this.btnedit.BackColor = System.Drawing.Color.Black;
            this.btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnedit.ForeColor = System.Drawing.Color.Yellow;
            this.btnedit.Location = new System.Drawing.Point(117, 316);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(82, 35);
            this.btnedit.TabIndex = 6;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = false;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click_1);
            // 
            // brand
            // 
            this.brand.BackColor = System.Drawing.Color.Black;
            this.brand.ForeColor = System.Drawing.Color.Yellow;
            this.brand.Location = new System.Drawing.Point(104, 158);
            this.brand.Margin = new System.Windows.Forms.Padding(4);
            this.brand.Name = "brand";
            this.brand.Size = new System.Drawing.Size(207, 26);
            this.brand.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(10, 158);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 24;
            this.label3.Text = "Brand";
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Black;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.ForeColor = System.Drawing.Color.Lime;
            this.btnadd.Location = new System.Drawing.Point(14, 316);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(82, 35);
            this.btnadd.TabIndex = 5;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // model
            // 
            this.model.BackColor = System.Drawing.Color.Black;
            this.model.ForeColor = System.Drawing.Color.Lime;
            this.model.Location = new System.Drawing.Point(104, 197);
            this.model.Margin = new System.Windows.Forms.Padding(4);
            this.model.Name = "model";
            this.model.Size = new System.Drawing.Size(207, 26);
            this.model.TabIndex = 2;
            // 
            // rno
            // 
            this.rno.BackColor = System.Drawing.Color.Black;
            this.rno.ForeColor = System.Drawing.Color.Red;
            this.rno.Location = new System.Drawing.Point(104, 114);
            this.rno.Margin = new System.Windows.Forms.Padding(4);
            this.rno.Name = "rno";
            this.rno.Size = new System.Drawing.Size(207, 26);
            this.rno.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(10, 200);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "Model";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(10, 117);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 20);
            this.label1.TabIndex = 19;
            this.label1.Text = "RegNo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(10, 239);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = "Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(10, 279);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 20);
            this.label6.TabIndex = 30;
            this.label6.Text = "Available";
            // 
            // price
            // 
            this.price.BackColor = System.Drawing.Color.Black;
            this.price.ForeColor = System.Drawing.Color.Red;
            this.price.Location = new System.Drawing.Point(104, 233);
            this.price.Margin = new System.Windows.Forms.Padding(4);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(207, 26);
            this.price.TabIndex = 3;
            // 
            // cartblBindingSource
            // 
            this.cartblBindingSource.DataMember = "Cartbl";
            // 
            // cartblBindingSource1
            // 
            this.cartblBindingSource1.DataMember = "Cartbl";
            // 
            // cartblBindingSource2
            // 
            this.cartblBindingSource2.DataMember = "Cartbl";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(0, 420);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(815, 26);
            this.panel2.TabIndex = 34;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // cartblBindingSource3
            // 
            this.cartblBindingSource3.DataMember = "Cartbl";
            // 
            // cartblBindingSource4
            // 
            this.cartblBindingSource4.DataMember = "Cartbl";
            // 
            // carDGV
            // 
            this.carDGV.BackgroundColor = System.Drawing.Color.Black;
            this.carDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.carDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.carDGV.Location = new System.Drawing.Point(386, 130);
            this.carDGV.Name = "carDGV";
            this.carDGV.Size = new System.Drawing.Size(417, 273);
            this.carDGV.TabIndex = 12;
            this.carDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.carDGV_CellContentClick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.Yellow;
            this.button1.Location = new System.Drawing.Point(668, 96);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 28);
            this.button1.TabIndex = 9;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.Color.Black;
            this.search.ForeColor = System.Drawing.Color.Red;
            this.search.FormattingEnabled = true;
            this.search.Items.AddRange(new object[] {
            "Available",
            "Rental"});
            this.search.Location = new System.Drawing.Point(485, 96);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(177, 28);
            this.search.TabIndex = 10;
            this.search.SelectionChangeCommitted += new System.EventHandler(this.search_SelectionChangeCommitted);
            // 
            // available
            // 
            this.available.AutoCompleteCustomSource.AddRange(new string[] {
            "Yes",
            "No"});
            this.available.BackColor = System.Drawing.Color.Black;
            this.available.ForeColor = System.Drawing.Color.Yellow;
            this.available.FormattingEnabled = true;
            this.available.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.available.Location = new System.Drawing.Point(104, 271);
            this.available.Name = "available";
            this.available.Size = new System.Drawing.Size(207, 28);
            this.available.TabIndex = 4;
            // 
            // Car
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(815, 444);
            this.Controls.Add(this.search);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.carDGV);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.available);
            this.Controls.Add(this.price);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnedit);
            this.Controls.Add(this.brand);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.model);
            this.Controls.Add(this.rno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Car";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Car";
            this.Load += new System.EventHandler(this.Car_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartblBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.TextBox brand;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.TextBox model;
        private System.Windows.Forms.TextBox rno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox price;
       // private carrentalDataSet2 carrentalDataSet2;
        private System.Windows.Forms.BindingSource cartblBindingSource;
      //  private carrentalDataSet2TableAdapters.CartblTableAdapter cartblTableAdapter;
      //  private carrentalDataSet carrentalDataSet1;
      //  private carrentalDataSet3 carrentalDataSet3;
        private System.Windows.Forms.BindingSource cartblBindingSource1;
       // private carrentalDataSet3TableAdapters.CartblTableAdapter cartblTableAdapter1;
       // private carrentalDataSet4 carrentalDataSet4;
        private System.Windows.Forms.BindingSource cartblBindingSource2;
       // private carrentalDataSet4TableAdapters.CartblTableAdapter cartblTableAdapter2;
       // private carrentalDataSet carrentalDataSet5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label7;
        //private carrentalDataSet18 carrentalDataSet18;
        private System.Windows.Forms.BindingSource cartblBindingSource3;
        //private carrentalDataSet18TableAdapters.CartblTableAdapter cartblTableAdapter3;
       // private carrentalDataSet24 carrentalDataSet24;
        private System.Windows.Forms.BindingSource cartblBindingSource4;
       // private carrentalDataSet24TableAdapters.CartblTableAdapter cartblTableAdapter4;
        private System.Windows.Forms.DataGridView carDGV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox search;
        private System.Windows.Forms.ComboBox available;
    }
}